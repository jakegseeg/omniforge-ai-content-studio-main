# Integration Request: "Edit Library" → Asset Library Page

## What needs to happen
In the **Asset Composer** screen (the post editor), there is a section in the left rail labeled **"Asset Library"** with a blue link that says **"Edit Library"** in the top-right corner of that section.

Right now clicking "Edit Library" does nothing (or goes nowhere).

**The fix:** When a user clicks "Edit Library", navigate them to the Asset Library page — which is the prototype file included in this zip (`asset-library-prototype.html`).

---

## Reference Screenshot
See Image 2 from the screenshots provided to Palmer — the Asset Composer screen.

In the left sidebar you'll see:
```
Asset Library          [Edit Library]  ← this blue text
[All] [Top] [Recent]
Browse categories
  Shapes  Graphics  Animations
  Photos  Videos    Audio
  ...
```

The **"Edit Library"** text is the clickable link that needs to route to the Asset Library.

---

## The Target Page
The Asset Library page is fully built. It is included in this zip as:
```
asset-library-prototype.html
```

It includes:
- All Assets grid with grade badges
- Brand Kit
- Snippets
- Hashtag Library
- AI Report panel (grade, platform scores, improvement tips, trend instructions)
- Upload flow with auto-grading
- Project switcher (top-right avatar)
- AI assist toggle

---

## How to implement this

### Option A — If the app is in React (Vite/Next.js)
```jsx
// In your AssetComposer component, find the Asset Library section header
// It probably looks something like this:

<div className="section-header">
  <span>Asset Library</span>
  <a href="/asset-library" className="edit-link">Edit Library</a>
</div>

// Make sure your router has this route defined:
// In your router config (React Router / Next.js pages):

// React Router:
<Route path="/asset-library" element={<AssetLibrary />} />

// Next.js:
// Create file: /pages/asset-library.tsx  or  /app/asset-library/page.tsx
```

### Option B — If linking between HTML files (prototype only)
```html
<!-- Find the "Edit Library" link in the composer HTML -->
<!-- Change it from plain text or a dead link to: -->

<a href="asset-library-prototype.html" style="color:#7C3AED; font-weight:500; font-size:12px; text-decoration:none;">
  Edit Library
</a>
```

### Option C — If using a navigation function / router push
```js
// Find where "Edit Library" is rendered and add:
onClick={() => router.push('/asset-library')}

// or with window.location for simple JS:
onclick="window.location.href='asset-library-prototype.html'"
```

---

## Design spec for the "Edit Library" link
To make sure it matches the existing blue link style in the composer:

```css
color: #7C3AED;        /* OmniForge purple */
font-size: 12px;
font-weight: 500;
text-decoration: none;
cursor: pointer;
```

On hover:
```css
color: #A78BFA;        /* lighter purple on hover */
text-decoration: underline;
```

---

## Navigation context
When the user clicks "Edit Library" and lands on the Asset Library:
- The **project context should carry over** — whatever project is selected in the Composer should be the active project in the Asset Library
- There should be a way to **go back** to the Composer — a back button or breadcrumb like:
  ```
  ← Back to Composer
  ```
- The Asset Library top nav tab "Asset Library" should appear **active** when they arrive

---

## Back button suggestion
At the top of the Asset Library page, add a back link:
```html
<div style="padding: 8px 14px; border-bottom: 1px solid #2E3147; display:flex; align-items:center; gap:6px;">
  <a href="composer.html" style="display:flex; align-items:center; gap:5px; color:#A0A4C0; font-size:12px; text-decoration:none;">
    <i class="ti ti-arrow-left" style="font-size:13px;"></i>
    Back to Composer
  </a>
</div>
```

---

## Files attached in this zip
| File | Description |
|------|-------------|
| `asset-library-prototype.html` | The full Asset Library page — drop this in your project |
| `README.md` | Feature list and screen map |
| `HANDOFF_PROMPT.md` | Full design system, colors, components — read this first |
| `INTEGRATION_PROMPT.md` | This file — the specific wiring task |

---

## Summary for AI tools (Cursor, Claude, GPT)
> In the OmniForge Asset Composer page, find the "Edit Library" blue link in the left sidebar Asset Library section. Wire it so clicking navigates to the Asset Library page. The Asset Library prototype is in `asset-library-prototype.html` in this zip. Use `#7C3AED` for the link color to match the app's purple accent. Add a "Back to Composer" link at the top of the Asset Library page. Pass the current project context through so the switcher stays in sync.

