# OmniForge — Asset Library Handoff Prompt

## Purpose of This File
This prompt is for any AI (Claude, GPT-4, Gemini, Cursor, etc.) receiving this folder. Read this before touching any file. It tells you exactly what has been built, what the design system is, and how the Asset Library connects to the rest of the app.

---

## App: OmniForge — AI Social Media Automation Studio
**Live URL:** https://omniforge-ai-content-studio-main.vercel.app  
**Stack:** React + Vite (main app) — Asset Library prototype is standalone HTML/CSS/JS  
**Designer:** Palmer Charles (Asset Library section only)

---

## Design System — Match These Exactly

### Colors
```
Background:        #0F1117   (page / darkest layer)
Surface (cards):   #1A1D27   (cards, panels)
Surface alt:       #13162B   (sidebar, top bars)
Surface raised:    #232636   (inputs, hover states)
Border:            #2E3147   (all borders)
Border mid:        #3A3E5C   (stronger borders)

Text primary:      #FFFFFF
Text secondary:    #A0A4C0
Text tertiary:     #6B7099

Purple primary:    #7C3AED   (buttons, active nav, accents)
Purple gradient:   linear-gradient(135deg, #7C3AED, #9333EA)
Purple dark bg:    #2D1F5E   (purple tinted backgrounds)
Purple light:      #C4B5FD   (purple tinted text on dark)

Green:             #10B981
Green dark bg:     #064E3B
Green light:       #6EE7B7

Amber:             #F59E0B
Amber dark bg:     #451A03 / #78350f
Amber light:       #FCD34D

Red:               #EF4444
Red dark bg:       #7f1d1d
Red light:         #FCA5A5
```

### Typography
- Font: Inter (Google Fonts)
- Nav labels: 13px / font-weight 500
- Active nav: font-weight 600
- Section headers: 10px / uppercase / letter-spacing .06em / color #6B7099
- Card titles: 12–13px / font-weight 600
- Body: 11–12px / color #A0A4C0
- Captions: 10px / color #6B7099

### Border Radius
- Cards: 10px
- Buttons: 7px
- Pills/chips: 99px
- Inputs: 7px
- Modal: 12px

### Icons
- Library: Tabler Icons v2.44.0
- CDN: `https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.44.0/tabler-icons.min.css`
- Usage: `<i class="ti ti-icon-name"></i>`

### Sidebar Nav Pattern (matches OmniForge exactly)
```html
<!-- Active state -->
<div style="background:#7C3AED; color:#fff; font-weight:600; border-radius:7px; padding:6px 10px;">
  <i class="ti ti-layout-grid"></i> All Assets
</div>
<!-- Inactive state -->
<div style="color:#A0A4C0; padding:6px 10px;">
  <i class="ti ti-palette"></i> Brand Kit
</div>
```

### Button Pattern
```html
<!-- Primary -->
<button style="background:linear-gradient(135deg,#7C3AED,#9333EA); color:#fff; border:none; border-radius:7px; padding:6px 12px; font-weight:600;">
  <i class="ti ti-sparkles"></i> Generate
</button>
<!-- Secondary -->
<button style="background:#232636; color:#A0A4C0; border:1px solid #2E3147; border-radius:7px; padding:6px 12px;">
  Edit
</button>
```

### Card Pattern
```html
<div style="background:#1A1D27; border:1px solid #2E3147; border-radius:10px; padding:14px;">
  <!-- content -->
</div>
```

---

## App Navigation Structure
```
OmniForge Sidebar:
├── Dashboard        → /dashboard
├── Idea Engine      → /idea-engine
├── Asset Composer   → /composer  (aka Post Composer)
├── Calendar         → /calendar
└── Settings         → /settings

Asset Library lives INSIDE Asset Composer as a sub-panel.
Access via "Edit Library" link in the Composer's left rail.
```

---

## What's in This Folder

| File | Description |
|------|-------------|
| `asset-library-prototype.html` | Full interactive prototype, dark theme, matches OmniForge |
| `README.md` | Full feature documentation and UX rationale |
| `HANDOFF_PROMPT.md` | This file — for AI tools to understand context |

---

## Asset Library — Feature Summary

### Owner: Palmer Charles
Palmer owns this entire section. Do not modify other sections of the app without Palmer's input.

### Critical Rule: NO MIXED PROJECTS
The project switcher (top-right avatar in app bar) scopes ALL content to one brand/client at a time. Like Slack workspaces — switching changes everything: assets, brand colors, snippets, hashtags. Never show assets from multiple projects at once.

### Screens
1. **All Assets** — grid of uploaded assets with grade badges, filter chips, sort
2. **Brand Kit** — colors, fonts, logos, tone keywords per project
3. **Snippets** — CTAs, testimonials, bios, service descriptions
4. **Hashtag Library** — grouped hashtag sets with reach data
5. **Asset Detail + AI Report** — right panel that loads on asset click

### AI Report (Right Panel) — 6 sections:
1. Overall grade ring (A/B/C) + score /100
2. 4 criteria bars: Brand alignment, Engagement potential, Platform fit, Copy quality
3. How to improve — prioritized suggestions (High/Med/Low) with effort level
4. Platform fit scores — Instagram, TikTok, Facebook, X (expandable per platform)
5. Best time to post — per platform with engagement heatmap
6. Trend instructions — numbered action steps, filterable by platform

### AI Toggle
- Toggle in center top bar turns AI features on/off
- OFF state: AI panel grays out, Analyze button disabled
- This is intentional — AI is optional per client brief

### Upload Flow
- Form → animated grading steps inside modal → grade result revealed in modal → closes and adds graded card to grid
- Auto-grades on upload (unlike viewing existing assets, which require manual trigger)

---

## Integration Points with Other Sections

### → Composer (Cohen's section)
- "Attach to post" button opens asset picker inside Composer
- Assets should be filterable by type and searchable
- Selected assets attach to the active post being composed

### → Idea Engine (Adam's section)
- Brand Kit tone keywords should feed into AI idea generation
- Asset thumbnails appear in generated idea cards as suggested media

### → Calendar (Jake's section)
- "Best time to post" data from AI report should eventually sync with Calendar scheduling
- Approved posts from Composer flow into Calendar

---

## What's Simulated vs Real
| Feature | Status |
|---------|--------|
| Asset grid rendering | ✅ Real (static data) |
| Upload modal flow | ✅ Interactive (simulated grading) |
| AI grade/analyze | 🟡 Simulated (random from samples) |
| Platform scores | 🟡 Hardcoded sample data |
| Best time to post | 🟡 Hardcoded sample data |
| Project switching | ✅ Real (updates labels + brand colors) |
| Hashtag groups | ✅ Real (static data) |
| Snippets | ✅ Real (static data) |

---

## If You Are Rebuilding This in React
```jsx
// Component tree suggestion:
<AssetLibrary>
  <AppBar projectSwitcher />
  <Sidebar>
    <NavItem icon="layout-grid" label="All Assets" />
    <NavItem icon="palette" label="Brand Kit" />
    <NavItem icon="text-size" label="Snippets" />
    <NavItem icon="hash" label="Hashtag Library" />
  </Sidebar>
  <Center>
    <CenterBar aiToggle uploadButton />
    <AssetGrid assets={assets} onSelect={selectAsset} />
  </Center>
  <RightPanel>
    <AssetDetails asset={selectedAsset} />
    <AIReport asset={selectedAsset} aiOn={aiOn} />
  </RightPanel>
</AssetLibrary>
```

---

## Tone / Aesthetic
The app is a **dark, professional SaaS tool** — not playful, not minimal-white. Think Linear, Vercel, or Supabase dashboard aesthetics. The purple accent is intentional and consistent across all sections. Every interactive element should have hover states. Loading/analyzing states use animated dots.

