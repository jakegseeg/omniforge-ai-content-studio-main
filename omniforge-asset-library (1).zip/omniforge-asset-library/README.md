# Asset Library Prototype — Project Handoff

## Project Overview
Interactive HTML prototype for the **Asset Library** section of OmniForge — an AI social media automation SaaS. Built by Palmer Charles (UX Designer & Front-End Developer, Utah Valley University).

**Live app:** https://omniforge-ai-content-studio-main.vercel.app

---

## Designer
Palmer Charles — UX Designer & Front-End Developer
BA Web Design & Development (UX focus), Utah Valley University
Contact: pacharles@charlesllc.com

---

## Critical Rule: No Mixed Projects
The project switcher (top-right avatar) scopes ALL content to one brand/client. Switching projects changes every asset, color, snippet, and hashtag shown — like Slack workspaces. Never mix content from different projects.

---

## How to Open
1. Open `asset-library-prototype.html` in Chrome, Safari, or Firefox
2. Internet connection required for Tabler icons (CDN)
3. Everything else is self-contained — no server needed

---

## Screens
| Screen | Access |
|--------|--------|
| All Assets | Default view |
| Brand Kit | Left rail → Brand Kit |
| Snippets | Left rail → Snippets |
| Hashtag Library | Left rail → Hashtag Library |
| Asset detail + AI report | Click any asset card |
| Upload + auto-grade | "Upload" button top bar |
| Project switch | Click avatar top-right |
| AI toggle | Toggle in center top bar |

---

## AI Report sections (right panel, per asset)
1. Overall score ring + letter grade (A/B/C)
2. Criteria bars: Brand alignment, Engagement potential, Platform fit, Copy quality
3. How to improve — prioritized suggestions with effort level
4. Platform fit scores — Instagram, TikTok, Facebook, X (click to expand)
5. Best time to post — per platform
6. Trend instructions — by platform tab

---

## Integration Points
- **→ Composer (Cohen):** "Attach to post" connects asset picker to post editor
- **→ Idea Engine (Adam):** Brand Kit tone keywords feed AI generation
- **→ Calendar (Jake):** Best post times eventually sync with scheduling

---

## Design System
See `HANDOFF_PROMPT.md` for full color palette, typography, component patterns, and React component tree suggestion.
